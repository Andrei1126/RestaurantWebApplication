-----Micut Andrei-Ion-----

									~RestaurantWebApplication~

Descriere:

	Am dorit sa creez o aplicatie in care avem o lista de restaurante de unde ne putem alege restaurantul preferat. Dupa ce am ales de unde dorim sa comandam, se va afisa o lista
de mancaruri dintre care putem alege ce sa mancam.


Modul de implementare:
  
  ~Models~
	Aceasta aplicatie ne ajuta sa intelegem cum functioneaza relatiile dintre bazele de date. Am folosit bazele de date RestaurantModel si FoodModel care nu pot fi legate direct, 
neputand sa existe o relatie one-to-many si, de aceea, am creat o a treia baza de date, FoodRestaurantModel. Astfel, am reusit sa realizez o legatura many-to-many intre tabele, datorita 
bazei de date FoodRestaurantModel.
	
  ~Data~
	In acest folder avem clasa DataContext in care se va afla baza de date, cele 3 liste si metodele ce ma vor ajuta sa afisez toate restaurantele (getAllRestaurants), sa adaug 
restaurante (addRestaurant), sa adaug mancare (addFood), sa afisez toate tipurile de mancaruri pentru un anumit restaurant (getAllFoodforRestaurant) si sa adaug o noua relatie
(addRelations).

  ~Controllers~
	in clasa MainController avem o ruta "api/controller" ce ne ajuta sa facem legatura dintre metode si bazele de date prin intermediul aplicatiei Postman.