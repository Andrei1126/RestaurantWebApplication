﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurants_DEMO.Models
{
    public class RestaurantModel
    {
        public int Id { get; set; }
        
        public String Name { get; set; }

        public String Address { get; set; }
    }
}
