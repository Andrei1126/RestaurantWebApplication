﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurants_DEMO.Models
{
    public class FoodRestaurantModel
    {
        public int Id { get; set; }

        public int RestaurantId { get; set; }

        public int FoodId { get; set; }
    }
}
