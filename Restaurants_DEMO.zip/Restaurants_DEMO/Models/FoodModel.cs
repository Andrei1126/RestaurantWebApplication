﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurants_DEMO.Models
{
    public class FoodModel
    {
        public int Id { get; set; }

        public String Name { get; set; }

        public String Ingredients { get; set; }
    }
}
