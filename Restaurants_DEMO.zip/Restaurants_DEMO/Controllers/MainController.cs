﻿using Microsoft.AspNetCore.Mvc;
using Restaurants_DEMO.Data;
using Restaurants_DEMO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurants_DEMO.Controllers
{
    [Route("api/controller")]
    public class MainController : Controller
    {
        static DataContext db = new DataContext();

        [HttpGet]
        [Route("")]
        public List<RestaurantModel> getRestaurants()
        {
            return db.getAllRestaurants();
        }

        [HttpPost]
        [Route("")]
        public void addRestaurant([FromBody]List<RestaurantModel> Restaurant)
        {
            foreach(var a in Restaurant)
            {
                db.addRestaurant(a);
            }
        }

        [HttpGet]
        [Route("Food")]
        public List<FoodModel> getFood([FromBody] int idRestaurant)
        {
            return db.getAllFoodforRestaurant(idRestaurant);
        }

        [HttpPost]
        [Route("Food")]

        public void addFood([FromBody]List<FoodModel> Food)
        {
            foreach (var a in Food)
            {
                db.addFood(a);
            }
        }

        [HttpPost]
        [Route("FoodRestaurant")]
        public void addFoodRestaurant([FromBody] List<FoodRestaurantModel> model)
        {
            foreach(var a in model)
            {
                db.addRelations(a);
            }
            
        }

    }
}
