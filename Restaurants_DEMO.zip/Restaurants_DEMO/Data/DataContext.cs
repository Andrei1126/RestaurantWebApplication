﻿using Restaurants_DEMO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurants_DEMO.Data
{
    public class DataContext
    {
        // aici va fi baza de date
        // vom face liste ce vor fi baze de date
        // listele tin de clasele in care le declar

        private static List<RestaurantModel> RestaurantList;
        private static List<FoodModel> FoodList;
        private static List<FoodRestaurantModel> FoodRestaurantList;

        public DataContext()
        {
            RestaurantList = new List<RestaurantModel>();
            FoodList = new List<FoodModel>();
            FoodRestaurantList = new List<FoodRestaurantModel>();
        }

        public List<RestaurantModel> getAllRestaurants()
        {
            return RestaurantList;
        }

        public void addRestaurant(RestaurantModel Restaurant)
        {
            RestaurantList.Add(Restaurant);
        }

        public void addFood(FoodModel Food)
        {
            FoodList.Add(Food);
        }

        public List<FoodModel> getAllFoodforRestaurant(int idRestaurant)
        {
            List<int> Food = new List<int>();
            List<FoodModel> FoodM = new List<FoodModel>();

            foreach(var a in FoodRestaurantList)
            {
                if(a.RestaurantId.Equals(idRestaurant))
                {
                    Food.Add(a.FoodId);
                }
            }

            foreach (var a in Food)
            {
                foreach (var b in FoodList)
                {
                    if(a.Equals(b.Id))
                    {
                        FoodM.Add(b);
                    }
                }
            }

            return FoodM;
        }

        public void addRelations(FoodRestaurantModel model)
        {
            FoodRestaurantList.Add(model);
        }
        

    }
}
